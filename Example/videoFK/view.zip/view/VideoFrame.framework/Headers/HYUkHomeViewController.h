//
//  HYUkHomeViewController.h
//  AFNetworking
//
//  Created by oceanMAC on 2023/4/27.
//

//#import "HYUkVideoBaseViewController.h"
//#import "HYUkHeader.h"
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HYUkHomeViewController : UIViewController

//@property (nonatomic, strong) HYUKVideoVersionModel *versionModel;

@end

NS_ASSUME_NONNULL_END
