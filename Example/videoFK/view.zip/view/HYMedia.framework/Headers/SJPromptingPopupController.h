//
//  SJPromptingPopupController.h
//  Pods
//
//  Created by 畅三江 on 2019/7/12.
//

#import "SJPromptingPopupControllerDefines.h"

NS_ASSUME_NONNULL_BEGIN

@interface SJPromptingPopupController : NSObject<SJPromptingPopupController>

@end

NS_ASSUME_NONNULL_END
