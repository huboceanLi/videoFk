//
//  SJTextPopupController.h
//  SJTextPopupControllerProject
//
//  Created by 畅三江 on 2017/9/26.
//  Copyright © 2017年 changsanjiang. All rights reserved.
//

#import "SJTextPopupControllerDefines.h"

NS_ASSUME_NONNULL_BEGIN
@interface SJTextPopupController : NSObject<SJTextPopupController>

@end
NS_ASSUME_NONNULL_END
