//
//  SJRotationManager_iOS_16_Later.h
//  SJVideoPlayer_Example
//
//  Created by 畅三江 on 2022/8/13.
//  Copyright © 2022 changsanjiang. All rights reserved.
//

#import "SJRotationManager.h"

API_AVAILABLE(ios(16.0)) NS_ASSUME_NONNULL_BEGIN
@interface SJRotationManager_iOS_16_Later : SJRotationManager

@end
NS_ASSUME_NONNULL_END
