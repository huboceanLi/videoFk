
//
//  HYMedia.h
//  HYMedia
//
//  Created by oceanMAC on 2023/9/26.
//

#import <Foundation/Foundation.h>

//! Project version number for HYMedia.
FOUNDATION_EXPORT double HYMediaVersionNumber;

//! Project version string for HYMedia.
FOUNDATION_EXPORT const unsigned char HYMediaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HYMedia/PublicHeader.h>

#import <HYMedia/HYVideoPlayView.h>
#import <HYMedia/SJRotationManager.h>
#import <HYMedia/SJBaseVideoPlayer.h>


