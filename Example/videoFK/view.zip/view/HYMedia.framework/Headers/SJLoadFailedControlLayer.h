//
//  SJLoadFailedControlLayer.h
//  SJVideoPlayer
//
//  Created by 畅三江 on 2018/10/27.
//  Copyright © 2018 畅三江. All rights reserved.
//

#import "SJNotReachableControlLayer.h"

#pragma mark - 加载失败或播放出错时显示的控制层


NS_ASSUME_NONNULL_BEGIN
@interface SJLoadFailedControlLayer : SJNotReachableControlLayer
@end
NS_ASSUME_NONNULL_END
