//
//  SJPlayerViewInternal.h
//  Pods
//
//  Created by 畅三江 on 2022/7/10.
//

#import "SJPlayerView.h"

NS_ASSUME_NONNULL_BEGIN
@interface SJPlayerView (Internal)
@property (nonatomic, strong, nullable) UIView *presentView;
@end
NS_ASSUME_NONNULL_END
