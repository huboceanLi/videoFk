//
//  SJRotationManager_iOS_9_15.h
//  SJVideoPlayer_Example
//
//  Created by 畅三江 on 2022/8/13.
//  Copyright © 2022 changsanjiang. All rights reserved.
//

#import "SJRotationManager.h"

NS_ASSUME_NONNULL_BEGIN
API_DEPRECATED("deprecated!", ios(9.0, 16.0)) @interface SJRotationManager_iOS_9_15 : SJRotationManager

@end
NS_ASSUME_NONNULL_END
